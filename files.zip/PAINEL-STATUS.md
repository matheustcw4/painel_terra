# Painel analítico + assistente — Plano do projeto (checkpoint 10/08/2026)

## Correção de escopo 12/08/2026 — o painel de BI é só operacional

Duas correções de rota anteriores neste documento (10/08 e 11/08) trataram Zeus e
Protector como parte natural do painel de gráficos, ao lado do operacional. Errado —
nunca foi isso que foi pedido. O `.pbix` e o print originais eram 100% Clockify + ERP
(hoje `TESTE_INTEGRACAO`); nenhuma tabela, nenhuma aba, nenhum print tinha clima ou
praga. Zeus/Protector foram um acréscimo meu, puxando do resto do projeto, nunca pedido
explicitamente pra esse painel.

**Decisão fechada**: o painel de gráficos (Fase 2) cobre só o domínio operacional.
Menu lateral: Chat, Geral, Operacional — sem Clima, sem Pragas. `Geral` é a mesma coisa
que a aba "Geral" do `.pbix` original (projetos atendidos, técnicos, horas apontadas,
custo/valor por hora), não uma visão cruzando domínios como um rascunho anterior deste
documento dizia.

**O que isso NÃO muda**: o chat continua com acesso a Zeus e Protector via MCP (Fase 1,
já funcionando) — essa correção é só sobre o BI/gráficos, não sobre quais MCPs o agente
enxerga. Se um dia fizer sentido ter páginas de Clima/Pragas no painel visual também,
isso é uma decisão nova, separada, não uma correção de algo já pedido.

## O que é isso

Painel web pra Terra Desenvolvimento Agropecuário, atrás de login simples, com dois tipos de conteúdo lado a lado: (1) gráficos/KPIs do domínio operacional (Clockify + ERP, via `TESTE_INTEGRACAO`) e (2) um chat que conversa com o agente (LangGraph + os 4 MCP servers: Zeus, Protector, operacional, relatorios-terra). Referência de estilo e de conteúdo pro BI: o `.pbix` e o PDF que você anexou.

## Correção de rota (versão anterior deste documento errou aqui)

A primeira versão deste plano tratou o dado de produtividade/contrato como algo a integrar do zero (Clockify, Google Agenda, ERP) — errado. Conferi as conversas de ontem: existe uma base Postgres própria, com pipeline Python já rodando (`python main.py`), schemas `erp` e `clockify`, alimentada por dois sistemas reais:

- **ERP interno "Terra"** (via Innofarmtech, `terra.innofarmtech.com.br/api/terra`) — clientes, contratos, fazendas, produtos/serviços, colaboradores. Schema `erp`: 11 tabelas + 3 views (`erp.base`, `erp.usuarios`, `erp.funcoes`, `erp.produtos`, `erp.contrato_fazendas`, entre outras).
- **Clockify** (`reports.api.clockify.me`) — horas apontadas por técnico/tarefa/tag, 365 dias corridos. Schema `clockify`: 1 tabela (`clockify.time_entries`, 24.087 linhas confirmadas na primeira carga).

Essa base já tem MCP registrado e testado — respondendo pergunta com exatidão, nas suas palavras. Nome do servidor: `TESTE_INTEGRACAO`, escopo local (só aparece dentro de `C:\Workspace\Jarvs - Terra\`) — isso é o comportamento certo, mesma lógica de isolar credencial por pasta que já vínhamos seguindo, não um problema. **Google Agenda não entra em lugar nenhum** — nem como base já pronta, nem como pendência futura; a aba "Agenda" do `.pbix` fica de fora do painel novo, ponto final.

Isso deixa dois grupos de dado com propósitos diferentes: **Zeus e Protector alimentam o chat** (o agente responde pergunta de clima/praga em linguagem natural), mas **não têm página de gráfico no painel** — isso nunca foi pedido pra esse painel especificamente. `TESTE_INTEGRACAO` (ERP+Clockify, operacional) é o único domínio com página de BI de verdade, porque foi o único mostrado no `.pbix`/print originais.

Nota à parte, sem travar nada: o nome `TESTE_INTEGRACAO` denuncia que nasceu como teste — funciona igual pro chat (é só o nome que o agente vê), mas se esse MCP vai virar dependência permanente do painel, vale renomear em algum momento tranquilo (`claude mcp get TESTE_INTEGRACAO` mostra a config atual pra copiar antes de remover e recriar com nome definitivo). Não precisa ser agora.

`postgres-econt` continua sendo outra coisa, ainda sem descrição no `router.md` — não é essa base de ERP/Clockify (são conexões diferentes, criadas em momentos diferentes). Não mexi nisso agora, só não quero deixar parecendo que resolvi.

## Stack (revisado — Streamlit foi abandonado)

Primeira tentativa da Fase 1 usou Streamlit — rejeitada: sem controle real de HTML/CSS,
resultado genérico demais pro padrão visual que o projeto já tem (identidade TERRA nos
PDFs). Reconstruído do zero com **FastAPI (backend) + React/Vite/Tailwind (frontend)**.
Efeito colateral bom, não só estético: FastAPI é async nativo, então o hack de
event-loop-em-thread que o Streamlit exigia (pra conciliar um framework síncrono com
LangGraph/MCP assíncronos) deixou de ser necessário — código mais simples, não mais
complexo, apesar do visual mais trabalhado.

## Fase 1 — entregue em 11/08/2026

**Testado de verdade, não só escrito**: login (senha errada → 401, senha certa → cookie
JWT), `/api/me`, chat em streaming batendo no MCP `relatorios-terra` de verdade
(produziu PDF real через o mecanismo completo). Dois bugs reais achados e corrigidos
rodando isso: `passlib` incompatível com `bcrypt` novo (trocado pelo pacote `bcrypt`
direto), e erro no meio do streaming que sumia sem chegar no cliente.

**Não testado, e por quê**: o agente decidindo qual ferramenta chamar a partir de
linguagem natural (sem chave de API Anthropic neste ambiente) e o resultado visual do
frontend (sem Chromium disponível pra screenshot — revisão foi por CSS realmente
compilado e leitura de código, não visual real).

Entrega: `painel-terra-fase1.zip` (backend + frontend completos) — README dentro com
o passo a passo de como rodar os dois processos.

## Estrutura de arquivos proposta

```
painel/                      → pasta nova, irmã de mcp_relatorios/ e docs/
  app.py                      → shell Streamlit, login, navegação entre abas
  auth.py                      → login simples (usuários/senha com hash)
  agente.py                     → monta LangGraph + langchain-mcp-adapters, expõe função de chat
  consultas/
    zeus.py                      → funções de consulta direta ao Postgres Zeus (sem MCP)
    protector.py                  → idem pro Protector
    operacional.py                 → idem pro banco por trás do TESTE_INTEGRACAO (erp + clockify)
  paginas/
    geral.py, clima.py, pragas.py  → uma aba por domínio
  requirements.txt
  .env.example                  → mesma disciplina do resto do projeto, nunca .env real versionado
```

## Fases

**Fase 1 — Fundação + chat funcionando (começo, vitória rápida)**
Login simples, shell do painel com a identidade visual já pronta, e o chat plugado no agente via `langchain-mcp-adapters` nos 4 MCPs já conectados. Essa fase é rápida porque reaproveita 100% de infraestrutura já testada nesta conversa — nenhum dado novo, nenhuma query nova, só ligar o fio.

**Fase 2 — Gráficos com dado real, só o operacional (meio)**
Camada de consulta SQL direta pro banco por trás do `TESTE_INTEGRACAO` (schemas `erp` + `clockify`) — mesmo padrão de separação chat/gráfico das outras fases, mas só esse domínio tem página no painel. Réplica das telas do estilo do `.pbix` (cards de KPI, filtros, abas: Geral e Operacional), sem a aba de Agenda. Zeus/Protector ficam de fora do painel visual — continuam só acessíveis via chat. Nota técnica: seu `.pbix` usa visuais pagos do marketplace (Pareto, ZebraBI, gráfico tipo Tornado) — esses não existem "de graça" fora do Power BI, os equivalentes em componente React/gráfico vão ficar parecidos, não idênticos pixel a pixel.

**Fase 3 — Produção**
Aqui encontra o plano de migração já fechado no projeto original (Fase 1/2/3 pro servidor OCI). O painel + LangGraph migram junto com os MCP servers quando virar algo que precisa rodar fora do seu notebook. Auth evolui de "lista simples" pra algo real se/quando cliente for acessar, não só equipe interna.

## Pendente — depende de você

- **Connection string real do `TESTE_INTEGRACAO`** (host/porta/banco) — o nome do servidor resolve o lado do chat, mas a Fase 2 consulta o Postgres direto, sem passar pelo MCP, e pra isso precisa da string de conexão, não só do nome. `claude mcp get TESTE_INTEGRACAO` mostra.
- Quem loga no painel: só equipe interna, ou já nasce pensando em cliente vendo o próprio dado? Muda o desenho do controle de acesso, não só o login.
- Confirma Streamlit ou prefere já ir de Next.js + FastAPI, aceitando o setup mais lento no início?

## Pendente — depende de gente de fora

- Fórmula de infestação do Protector (agrônomo) — mesma pendência de sempre.
- O que `postgres-econt` cobre de verdade — ainda ninguém preencheu, e agora está confirmado que não é a base de ERP/Clockify (são conexões diferentes).

## Como retomar

Se for nessa mesma conversa, é só continuar da Fase 1. Se abrir uma conversa nova, cola esse arquivo (junto com `PROJETO-STATUS.md`) no início da mensagem.
